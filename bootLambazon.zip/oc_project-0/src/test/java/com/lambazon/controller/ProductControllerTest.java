package com.lambazon.controller;

import static org.junit.Assert.*;

public class ProductControllerTest {

}